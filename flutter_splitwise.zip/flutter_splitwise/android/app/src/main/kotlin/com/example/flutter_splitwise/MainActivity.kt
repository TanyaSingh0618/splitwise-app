package com.example.flutter_splitwise

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
