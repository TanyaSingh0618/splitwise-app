import 'dart:convert';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:flutter_splitwise/controllers/main_controller.dart';
import 'package:flutter_splitwise/models/friend.dart';
import 'package:flutter_splitwise/models/tansaction.dart';
import 'package:get/get.dart';

class OperationsController extends GetxController {
  late final FirebaseDatabase databaseReference;

  final friends = RxList<Friend>();
  final expenses = RxList<Expense>();

  final oweBalance = RxNum(0.0);
  final owedBalance = RxNum(0.0);

  @override
  void onInit() {
    databaseReference = FirebaseDatabase.instance
      ..databaseURL =
          "https://flutter-splitwise-default-rtdb.asia-southeast1.firebasedatabase.app"
      ..setPersistenceEnabled(true);
    ever(friends, _calculateBalance);
    _loadInitialData();
    super.onInit();
  }

  void _calculateBalance(List<Friend> friends) {
    oweBalance.value = 0.0;
    owedBalance.value = 0.0;
    for (var friend in friends) {
      if (friend.status == "you owe") {
        oweBalance.value += friend.amount;
      } else if (friend.status == "owes you") {
        owedBalance.value += friend.amount;
      }
    }
  }

  _loadInitialData() {
    _loadFriends();
    _loadExpense();
  }

  addFirend(String name, String email, CreditStatus status, double amount,
      {required BuildContext context}) async {
    Loader.show(context);
    await databaseReference
        .ref(Get.find<MainController>().uid.value)
        .child("/friends")
        .push()
        .set({
      "name": name,
      "amount": amount,
      "status": status == CreditStatus.owe
          ? "you owe"
          : status == CreditStatus.owed
              ? "owes you"
              : "settled up",
      "email": email,
    }).then((value) => _loadFriends());
    Loader.hide();
    Get.back();
  }

  _loadFriends() {
    friends.value.clear();
    databaseReference
        .ref(Get.find<MainController>().uid.value)
        .child("/friends")
        .get()
        .then((snapshot) {
      try {
        Map<dynamic, dynamic> val = snapshot.value as Map<dynamic, dynamic>;
        val.forEach((key, value) {
          friends.add(Friend(
            name: value["name"],
            email: value["email"],
            status: value["status"],
            amount: (value["amount"]),
          ));
        });
        print(friends.value.length);
      } catch (e) {
        print(e);
      }
    });
  }

  addExpense(String name, String email, String title, bool youPaid, num amount,
      BuildContext context) async {
    Loader.show(context);
    await databaseReference
        .ref(Get.find<MainController>().uid.value)
        .child("/transactions")
        .push()
        .set({
      "email": email,
      "title": title,
      "name": name,
      "youPaid": youPaid,
      "amount": amount,
    }).then((value) {
      _updateFriend(email, youPaid ? (amount / 2) : -(amount / 2));
      _loadExpense();
    });
    Loader.hide();
    Get.back();
  }

  _updateFriend(
    String email,
    num amount,
  ) {
    databaseReference
        .ref(Get.find<MainController>().uid.value)
        .child("/friends")
        .orderByChild("email")
        .equalTo(email)
        .once()
        .then((snapshot) {
      try {
        Map<dynamic, dynamic> val =
            snapshot.snapshot.value as Map<dynamic, dynamic>;
        val.forEach((key, value) {
          databaseReference
              .ref(Get.find<MainController>().uid.value)
              .child("/friends")
              .child(key)
              .update({
            "status": value["amount"] + amount < 0
                ? "you owe"
                : value["amount"] + amount > 0
                    ? "owes you"
                    : "settled up",
            "amount": (value["amount"] + amount).abs(),
          });
        });
      } catch (e) {}
    }).then((value) => _loadFriends());
  }

  _loadExpense() {
    expenses.value.clear();
    databaseReference
        .ref(Get.find<MainController>().uid.value)
        .child("/transactions")
        .get()
        .then((snapshot) {
      try {
        Map<dynamic, dynamic> val = snapshot.value as Map<dynamic, dynamic>;
        val.forEach((key, value) {
          expenses.value.add(Expense(
            name: value["name"],
            email: value["email"],
            youPaid: value["youPaid"],
            amount: (value["amount"]),
            title: value["title"],
          ));
        });
      } catch (e) {
        print(e);
      }
    });
  }
}

enum CreditStatus { owe, owed, settled }
