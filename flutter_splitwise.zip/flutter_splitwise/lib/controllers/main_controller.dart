import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_loader/flutter_overlay_loader.dart';
import 'package:flutter_splitwise/Components/home.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';

class MainController extends GetxController {
  // *
  final name = "".obs;
  final email = "".obs;
  final avatar = "".obs;
  final uid = "".obs;

  @override
  void onInit() {
    _setupFirebase();
    super.onInit();
  }

  _setupFirebase() async {
    await Firebase.initializeApp();
  }

  Future<bool> signInWithGoogle({required BuildContext context}) async {
    FirebaseAuth auth = FirebaseAuth.instance;
    bool _status = false;

    final GoogleSignIn googleSignIn = GoogleSignIn();

    Loader.show(context);

    final GoogleSignInAccount? googleSignInAccount =
        await googleSignIn.signIn();

    if (googleSignInAccount != null) {
      try {
        final GoogleSignInAuthentication googleSignInAuthentication =
            await googleSignInAccount.authentication;
        Loader.hide();

        name.value = googleSignInAccount.displayName ?? "NaN";
        email.value = googleSignInAccount.email ?? "NaN";
        uid.value = googleSignInAccount.id ?? "NaN";
        avatar.value = googleSignInAccount.photoUrl ??
            'https://caseyboz10331.files.wordpress.com/2014/05/20140510-195426.jpg';

        WidgetsBinding.instance!.addPostFrameCallback((_) {
          Get.offAll(HomeScreen());
        });
      } on FirebaseAuthException catch (e) {
        Loader.hide();

        if (e.code == 'account-exists-with-different-credential') {
          ScaffoldMessenger.of(context).showSnackBar(
            customSnackBar(
              content:
                  'The account already exists with a different credential.',
            ),
          );
        } else if (e.code == 'invalid-credential') {
          ScaffoldMessenger.of(context).showSnackBar(
            customSnackBar(
              content: 'Error occurred while accessing credentials. Try again.',
            ),
          );
        }
      } catch (e) {
        Loader.hide();
        ScaffoldMessenger.of(context).showSnackBar(
          customSnackBar(
            content: 'Error occurred using Google Sign-In. Try again.',
          ),
        );
      }
    }

    return _status;
  }

  static SnackBar customSnackBar({required String content}) {
    return SnackBar(
      backgroundColor: Colors.black,
      content: Text(
        content,
        style: const TextStyle(color: Colors.redAccent, letterSpacing: 0.5),
      ),
    );
  }
}
