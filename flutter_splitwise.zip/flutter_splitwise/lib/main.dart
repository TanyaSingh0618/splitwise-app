import 'package:flutter/material.dart';
import 'package:flutter_splitwise/Components/onboarding.dart';
import 'package:flutter_splitwise/controllers/main_controller.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:get/instance_manager.dart';

void main() {
  runApp(MyApp());
  Get.put(MainController());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Flutter Splitwise',
      home: MyHome(),
    );
  }
}

class MyHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return OnboardingScreen();
  }
}
