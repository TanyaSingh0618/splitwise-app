import 'package:flutter/material.dart';
import 'package:flutter_splitwise/controllers/operations_controller.dart';
import 'package:flutter_splitwise/models/tansaction.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/get_state_manager.dart';

class Activity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              Expanded(flex: 1, child: Text("")),
              Expanded(
                  flex: 4,
                  child: Text(
                    "Transaction",
                    textAlign: TextAlign.center,
                  )),
              Expanded(flex: 3, child: Text('User', textAlign: TextAlign.end)),
            ],
          ),
        ),
        Obx(() => ListView.builder(
              itemBuilder: (BuildContext context, int index) {
                return Tansaction(
                    expense:
                        Get.find<OperationsController>().expenses.value[index]);
              },
              shrinkWrap: true,
              itemCount: Get.find<OperationsController>().expenses.value.length,
            )),
      ],
    );
  }
}

class Tansaction extends StatelessWidget {
  const Tansaction({Key? key, required this.expense}) : super(key: key);

  final Expense expense;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: SizedBox(
          width: 70,
          child: Icon(
            Icons.account_balance_wallet_outlined,
            color: Color.fromRGBO(91, 197, 167, 1),
            size: 50,
          )),
      title: Text(
        (expense.youPaid ? "YOU" : expense.name) +
            " paid " +
            expense.amount.toString() +
            "\$",
        style: TextStyle(
          color: expense.youPaid ? Color.fromRGBO(91, 197, 167, 1) : Colors.red,
        ),
      ),
      subtitle: Text(expense.title),
      trailing: Text(expense.name.toString()),
    );
  }
}
