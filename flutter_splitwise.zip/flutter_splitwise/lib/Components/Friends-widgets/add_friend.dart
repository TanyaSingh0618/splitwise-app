import 'package:flutter/material.dart';
import 'package:flutter_splitwise/controllers/operations_controller.dart';
import 'package:get/instance_manager.dart';

class AddFriendForm extends StatelessWidget {
  AddFriendForm({Key? key}) : super(key: key);

  final _formKey = GlobalKey<FormState>();

  final emailController = TextEditingController();
  final nameController = TextEditingController();

  String? _checkIsEmpty(String? value) {
    return value == null || value.isEmpty ? "Enter a vlue" : null;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
        title: const Text('Add a friend'),
        content: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'Name',
                ),
                validator: _checkIsEmpty,
              ),
              TextFormField(
                controller: emailController,
                decoration: const InputDecoration(
                  labelText: 'Email',
                ),
                validator: _checkIsEmpty,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 20.0),
                child: ElevatedButton(
                  child: const Text('Add'),
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      Get.find<OperationsController>().addFirend(
                          nameController.text.trim(),
                          emailController.text.trim(),
                          CreditStatus.settled,
                          0,
                          context: context);
                    }
                  },
                ),
              ),
            ],
          ),
        ));
  }
}
