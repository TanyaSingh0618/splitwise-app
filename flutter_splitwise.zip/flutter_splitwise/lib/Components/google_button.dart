import 'package:flutter/material.dart';

import 'package:get/get_utils/src/extensions/internacionalization.dart';

class GoogleSignInButton extends StatefulWidget {
  const GoogleSignInButton({
    Key? key,
    required this.onPressed,
  }) : super(key: key);

  final VoidCallback onPressed;

  @override
  _GoogleSignInButtonState createState() => _GoogleSignInButtonState();
}

class _GoogleSignInButtonState extends State<GoogleSignInButton> {
  bool _isSigningIn = false;

  _GoogleSignInButtonState();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: _isSigningIn
          ? const CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            )
          : OutlinedButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.orange),
                shape: MaterialStateProperty.all(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(40),
                  ),
                ),
              ),
              onPressed: () async {
                setState(() {
                  _isSigningIn = true;
                });
                widget.onPressed();

                setState(() {
                  _isSigningIn = false;
                });
              },
              child: Padding(
                padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Text(
                        'Sign in with Google'.tr,
                        style: TextStyle(
                          fontSize: 15,
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),

      // OutlinedButton(
      //     style: ButtonStyle(
      //       backgroundColor:
      //           MaterialStateProperty.all(ColorName.accentPrimary),
      //       shape: MaterialStateProperty.all(
      //         RoundedRectangleBorder(
      //           borderRadius: BorderRadius.circular(40),
      //         ),
      //       ),
      //     ),
      //     onPressed: () async {
      //       setState(() {
      //         _isSigningIn = true;
      //       });
      //       widget.onPressed();

      //       setState(() {
      //         _isSigningIn = false;
      //       });
      //     },
      //     child:

      //      Padding(
      //       padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
      //       child: Row(
      //         mainAxisSize: MainAxisSize.min,
      //         mainAxisAlignment: MainAxisAlignment.center,
      //         children: <Widget>[
      //           Assets.icons.googleLogo.image(
      //             height: 20.0,
      //           ),
      //           Padding(
      //             padding: const EdgeInsets.symmetric(horizontal: 10),
      //             child: Text(
      //               'Sign in with Google'.tr,
      //               style: TextStyle(
      //                 fontSize: Dimens.fourteen,
      //                 color: ColorName.primaryFont,
      //                 fontWeight: FontWeight.w600,
      //               ),
      //             ),
      //           )
      //         ],
      //       ),
      //     ),
      //   ),
    );
  }
}
