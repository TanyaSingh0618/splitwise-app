import 'package:flutter/material.dart';
import 'package:flutter_splitwise/Components/Friends-widgets/add_friend.dart';
import 'package:flutter_splitwise/Components/expense.dart';
import 'package:flutter_splitwise/controllers/operations_controller.dart';
import 'package:get/get.dart';
import 'share-widgets/page_filter.dart';
import 'friends-widgets/friend_row.dart';
import 'package:intl/intl.dart';

class Friends extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        width: double.infinity,
        child: Column(
          children: <Widget>[
            PageFilter(),
            Obx(() => ListView.builder(
                  shrinkWrap: true,
                  itemCount:
                      Get.find<OperationsController>().friends.value.length,
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: (() => Get.to(Expense(
                          name: Get.find<OperationsController>()
                              .friends
                              .value[index]
                              .name,
                          email: Get.find<OperationsController>()
                              .friends
                              .value[index]
                              .email))),
                      child: FriendRow(Get.find<OperationsController>()
                          .friends
                          .value[index]),
                    );
                  },
                )),
            // ..._friends
            //     .map((friend) => FriendRow(
            //         friend['name'] as String,
            //         friend['status'] as String,
            //         NumberFormat.currency(symbol: 'S\$')
            //             .format(friend['amount'])))
            //     .toList(),
            Container(
                margin: EdgeInsets.fromLTRB(20, 25, 20, 15),
                child: Text(
                    'Splitwise hides friends who have been settled up for more than 7 days.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey[600]))),
            ElevatedButton(
              onPressed: () {},
              child: Text('Show x settled-up friend',
                  style: TextStyle(
                      color: Color.fromRGBO(91, 197, 167, 1), fontSize: 12)),
              style: ElevatedButton.styleFrom(
                  primary: Colors.white,
                  onPrimary: Color.fromRGBO(91, 197, 167, 1),
                  side: BorderSide(
                      color: Color.fromRGBO(91, 197, 167, 1), width: 2)),
            ),
            Container(
                margin: EdgeInsets.fromLTRB(20, 0, 20, 0),
                child: Row(
                  children: [
                    Expanded(
                        child: ElevatedButton(
                            onPressed: () {
                              Get.dialog(
                                AddFriendForm(),
                              );
                            },
                            child: Text(
                              '+ ADD MORE FRIENDS',
                              style: TextStyle(
                                  color: Colors.grey[900], fontSize: 12),
                            ),
                            style: ElevatedButton.styleFrom(
                              primary: Colors.grey[200],
                            )))
                  ],
                )),
          ],
        ));
  }
}
