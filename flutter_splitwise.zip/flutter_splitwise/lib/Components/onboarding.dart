import 'package:flutter/material.dart';
import 'package:flutter_splitwise/Components/google_button.dart';
import 'package:get/get.dart';

import '../controllers/main_controller.dart';

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: GoogleSignInButton(
          onPressed: () {
            Get.find<MainController>().signInWithGoogle(context: context);
          },
        ),
      ),
    );
  }
}
