import 'package:flutter/material.dart';
import 'package:flutter_splitwise/Components/onboarding.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../controllers/main_controller.dart';

class Sidebar extends StatelessWidget {
  Widget _createDrawerItem(
      {required IconData icon,
      required String text,
      GestureTapCallback? onTap}) {
    return ListTile(
      title: Row(
        children: <Widget>[
          Icon(icon),
          Padding(
            padding: EdgeInsets.only(left: 8.0),
            child: Text(text),
          )
        ],
      ),
      onTap: onTap,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: <Widget>[
          DrawerHeader(
              decoration: BoxDecoration(color: Colors.lightGreen),
              child: Stack(
                children: <Widget>[
                  Positioned(
                    bottom: 30.0,
                    child: Obx(() => Text(
                          Get.find<MainController>().name.value,
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18.0,
                              fontWeight: FontWeight.bold),
                        )),
                  ),
                  Positioned(
                    bottom: 8.0,
                    child: Obx(() => Text(
                          Get.find<MainController>().email.value,
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 14.0,
                              fontWeight: FontWeight.normal),
                        )),
                  ),
                  Positioned(
                    bottom: 70.0,
                    child: CircleAvatar(
                      radius: 30,
                      child: ClipOval(
                        child: new SizedBox(
                          width: 100.0,
                          height: 100.0,
                          child: Obx(() => Image.network(
                                Get.find<MainController>().avatar.value,
                                fit: BoxFit.fill,
                              )),
                        ),
                      ),
                    ),
                  ),
                ],
              )),
          /*Row(
                  children: <Widget>[
                    Text('Try Pro!'),
                  ],
                ),
                Divider(
                  color: Colors.grey,
                  thickness: 0.5,
                ),*/
          _createDrawerItem(
            icon: Icons.home,
            text: 'Home',
          ),
          _createDrawerItem(
            icon: Icons.settings,
            text: 'Settings',
          ),
          _createDrawerItem(
            icon: Icons.qr_code_scanner,
            text: 'Scan code',
          ),
          _createDrawerItem(
              icon: Icons.logout,
              text: 'Log out',
              onTap: () async {
                await GoogleSignIn().signOut();
                Get.offAll(OnboardingScreen());
              })
        ],
      ),
    );
  }
}
