import 'package:flutter/material.dart';
import 'package:flutter_splitwise/Components/sidebar.dart';
import 'package:flutter_splitwise/controllers/operations_controller.dart';
import 'package:get/get.dart';

import 'expense.dart';
import 'main_tab_bar.dart';
import 'main_tab_bar_view.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    Key? key,
  }) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    Get.put(OperationsController());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromRGBO(59, 174, 142, 1),
          title: Text('SplitWise'),
          actions: <Widget>[
            IconButton(icon: const Icon(Icons.search), onPressed: null),
            PopupMenuButton(
                icon: Icon(Icons.more_vert),
                itemBuilder: (context) => [
                      PopupMenuItem(
                        child: Text('Add friends on Splitwise'),
                      ),
                      PopupMenuItem(
                        child: Text('Create a group'),
                      ),
                    ]),
          ],
          bottom: MainTabBar(),
        ),
        // floatingActionButton: FloatingActionButton(
        //   child: Icon(Icons.add),
        //   backgroundColor: Colors.orange[800],
        //   onPressed: () {
        //     Navigator.push(
        //         context,
        //         MaterialPageRoute(
        //           builder: (context) => Expense(),
        //         ));
        //   },
        // ),
        drawer: Sidebar(),
        body: MainTabBarView(),
      ),
    );
  }
}
