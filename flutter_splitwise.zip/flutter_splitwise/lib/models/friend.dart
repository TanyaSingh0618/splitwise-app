
import 'dart:convert';

List<Friend> friendFromJson(String str) => List<Friend>.from(json.decode(str).map((x) => Friend.fromJson(x)));

String friendToJson(List<Friend> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Friend {
    Friend({
        required this.name,
        required this.email,
        required this.status,
        required this.amount,
    });

    String name;
    String email;
    String status;
    num amount;

    factory Friend.fromJson(Map<String, dynamic> json) => Friend(
        name: json["name"],
        email: json["email"],
        status: json["status"],
        amount: json["amount"].toDouble(),
    );

    Map<String, dynamic> toJson() => {
        "name": name,
        "email": email,
        "status": status,
        "amount": amount,
    };
}