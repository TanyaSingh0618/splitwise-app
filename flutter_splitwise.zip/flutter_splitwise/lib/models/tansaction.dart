class Expense {
  String email;
  String name;
  String title;
  bool youPaid;
  num amount;
  Expense({
    required this.email,
    required this.name,
    required this.title,
    required this.amount,
    required this.youPaid,
  });
}
